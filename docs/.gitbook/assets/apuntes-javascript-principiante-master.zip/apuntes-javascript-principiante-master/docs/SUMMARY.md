# Summary

* [Prólogo](prologo/README.md)
* [Primeros pasos con Javascript](como_empezar/README.md)
* [Ideas Claras de Javascript](generalidades/README.md)
* [Variables y Operadores](variables_operadores/README.md)
* [Condiciones y Bucles](condiciones-bucles/README.md)
* [Funciones](funciones/README.md)
* [Arrays y Objetos](arrays-y-objetos/README.md)
* [Objetos Globales](objetos-globales/README.md)
* [El entorno del Navegador](entorno_navegador/README.md)
* [BOM](bom/README.md)
* [DOM](dom/README.md)
* [Events](eventos/README.md)
    

