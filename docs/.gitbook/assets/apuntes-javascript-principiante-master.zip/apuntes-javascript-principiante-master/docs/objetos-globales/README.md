# Objetos Globales

Son los objetos que tenemos disponibles en el ámbito global (objetos primitivos)

Los podemos dividir en 3 grupos

- _Objetos contenedores de datos_:  Object, Array, Function, Boolean, Number
- _Objetos de utilidades_: Math, Date, RegExp
- _Objetos de errores_: Error

- En este primer libro vamos a ver sólo los _objetos contenedores de datos_

##[Object](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Object)

**Object** es el padre de todos los objetos Javascript, es decir, cualquier objeto hereda de él

Para crear un objeto vacio podemos usar:

- La notacion literal :  `var o = {}`
- La funcion constructora Object():  `var o = new Object();`

```javascript
>>> var o = new Object();
>>> o.toString()
“[object Object]”

>>> o.valueOf() === o
true
```

##[Array](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array)

Para crear arrays podemos usar:

- La notacion literal :  `var a = []`
- La funcion constructora Array():  `var o = new Array();`

Podemos pasarle parametros al constructor `Array()`

- Varios parametros: Seran asignados como elementos al array
- Un numero: Se considerará el tamaño del array

```javascript
>>> var a = new Array(1,2,3,'four');
>>> a;
[1, 2, 3, "four"]

>>> var a2 = new Array(5);
>>> a2;
[undefined, undefined, undefined, undefined, undefined]
```

Como los arrays son objetos tenemos disponibles los metodos y propiedades del padre `Object()`

```javascript
>>> typeof a;
"object"

>>> a.toString();
"1,2,3,four"
>>> a.valueOf()
[1, 2, 3, "four"]
>>> a.constructor
Array()
```

Los arrays disponen de la propiedad [`length`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/length)  

- Nos devuelve el tamaño del array (numero de elementos)
- Podemos  modificarlo y cambiar el tamaño del array

```javascript
>>> a[0] = 1; 
>>> a.prop = 2; 

>>> a.length
1
>>> a.length = 5
5
>>> a
[1, undefined, undefined, undefined, undefined]

>>> a.length = 2;
2
>>> a
[1, undefined]
```
  
  
Los arrays disponen de unos cuantos metodos interesantes:

- `push()`
- `pop()`
- `sort()`
- `join()`
- `slice()`
- `splice()`

```javascript
>>> var a = [3, 5, 1, 7, 'test'];

>>> a.push('new') 
6
>>> a 
[3, 5, 1, 7, "test", "new"]

>>> a.pop() 
"new"
>>> a 
[3, 5, 1, 7, "test"]

>>> var b = a.sort();
>>> b
[1, 3, 5, 7, "test"]
>>> a
[1, 3, 5, 7, "test"]

>>> a.join(' is not ');
"1 is not 3 is not 5 is not 7 is not test"

>>> b = a.slice(1, 3);
[3, 5]
>>> a
[1, 3, 5, 7, "test"]

>>> b = a.splice(1, 2, 100, 101, 102);
[3, 5]
>>> a
[1, 100, 101, 102, 7, "test"]
```

###[`push()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/push)

`push()` inserta elementos al final del array  
`a.push('new')` es lo mismo que `a[a.length] = 'new'`  
`push()` devuelve el tamaño del array modificado  

```javascript
>>> var sports = ['soccer', 'baseball'];
>>> sports
["soccer", "baseball"]
>>> sports.length
2
>>> sports.push('football', 'swimming');
4
>>> sports
["soccer", "baseball", "football", "swimming"]
```

###[`pop()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/pop)

`pop()` elimina el ultimo elemento   
`a.pop()` es lo mismo que `a.length--`;  
`pop()` devuelve el elemento eliminado  

```javascript
>>> var myFish = ['angel', 'clown', 'mandarin', 'sturgeon'];
>>> myFish
["angel", "clown", "mandarin", "sturgeon"]
>>> myFish.pop();
"sturgeon"
>>> myFish
["angel", "clown", "mandarin"]
```

###[`sort()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/sort)

ordena el array y devuelve el array modificado

```javascript
>>> var fruit = ['apples', 'bananas', 'Cherries'];
>>> fruit
["apples", "bananas", "Cherries"]
>>> fruit.sort();
["Cherries", "apples", "bananas"]

>>> var scores = [1, 2, 10, 21];
>>> scores
[1, 2, 10, 21]
>>> scores.sort()
[1, 10, 2, 21]
```

```javascript
>>> var numbers = [4, 2, 42, 36, 5, 1, 12, 3];
>>> numbers
[4, 2, 42, 36, 5, 1, 12, 3]
>>> numbers.sort()
[1, 12, 2, 3, 36, 4, 42, 5]
>>> numbers.sort( function(a, b) { return a - b; } );
[1, 2, 3, 4, 5, 12, 36, 42]
```

###[`join()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/join)

`join()` devuelve una cadena (string) con los valores de los elementos del array 

```javascript
>>> var a = ['Wind', 'Rain', 'Fire'];
>>> a.join();
"Wind,Rain,Fire"
>>> a.join(" - ");
"Wind - Rain - Fire"
>>> typeof ( a.join(" - ") )
"string"
```

###[`slice()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/slice)

`slice()` devuelve un trozo del array  sin modficar el original 

```javascript
>>> var fruits = ['Banana', 'Orange', 'Lemon', 'Apple', 'Mango'];
>>> var citrus = fruits.slice(1, 3);
>>> fruits
["Banana", "Orange", "Lemon", "Apple", "Mango"]
>>> citrus
["Orange", "Lemon"]
```

###[`splice()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/splice)

`splice()` quita un trozo del array, lo devuelve  y opcionalmente rellena el hueco con nuevos elementos 

```javascript
>>> var myFish = ['angel', 'clown', 'mandarin', 'surgeon'];

>>> myFish
["angel", "clown", "mandarin", "surgeon"]
>>> var removed = myFish.splice(2, 1);

>>> myFish
["angel", "clown", "surgeon"]
>>> removed
["mandarin"]

>>> var removed = myFish.splice(2, 0, 'drum');
>>> myFish
["angel", "clown", "drum", "surgeon"]
>>> removed
[]
```

##[Function](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Function)

Las funciones son objetos

Podemos crear funciones con la función constructora `Function()` (aunque este metodo no se recomienda ya que internamente hace un _eval()_ )

```javascript
>>> function sum(a, b) {return a + b;};
>>> sum(1, 2)
3
>>> var sum = function(a, b) {return a + b;};
>>> sum(1, 2)
3
>>> var sum = new Function('a', 'b', 'return a + b;');
>>> sum(1, 2)
3
```

Las funciones disponen de la propiedad [`length`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Function/length) que contiene el numero de parametros que acepta la función 

```javascript
>>> function myfunc(a, b, c){ return true; }
>>> myfunc.length
3
```

##[Boolean](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Boolean)

El objeto _Boolean_ es un contenedor para un valor de tipo booleano  

Podemos crear objetos _Boolean_ con la función constructora `Boolean()`

```javascript
>>> var b = new Boolean();
>>> typeof b 
"object"
>>> typeof b.valueOf() 
"boolean"
>>> b.valueOf() 
false
```

La función `Boolean` usada como función normal (sin `new`) nos devuelve el valor pasado como parametro convertido a booleano

```javascript
>>> Boolean("test") 
true
>>> Boolean("") 
false
>>> Boolean({}) 
true
```

##[Number](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Number)

La función `Number()` puede ser usada:

- Cómo una _función normal_ para convertir valores a número
- Cómo una _función constructora_ (con `new`) para crear objetos

Los objetos número disponen de los métodos: [`toFixed()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Number/toFixed), [`toPrecision()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Number/toPrecision) y [`toExponential()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Number/toExponential)

```javascript
>>> var n = new Number(123.456)
>>> n.toFixed(1) 
"123.5"

>>> (12345).toExponential() 
"1.2345e+4"
```

El método [`toString()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Number/toString) de un objeto numero nos permite transformar un numero a una base determinada 

```javascript
>>> var n = new Number(255);
>>> n.toString(); 
"255"
>>> n.toString(10); 
"255"
>>> n.toString(16); 
"ff"
>>> (3).toString(2); 
"11"
>>> (3).toString(10); 
"3"
```

##[String](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/String)

Podemos crear objetos String con la función constructora `String()`  

Un objeto _String_ NO es un dato de tipo primitivo string (`valueOf()`)

```javascript
>>> var primitive = 'Hello';
>>> typeof primitive; 
"string"
>>> var obj = new String('world');
>>> typeof obj; 
"object"

>>> Boolean("") 
false
>>> Boolean(new String("")) 
true
```

Un objeto string es parecido a un array de caracteres:

- Cada carácter tiene una posición indexada
- Tiene disponible la propiedad length

```javascript
>>> obj[0] 
"w"
>>> obj[4] 
"d"
>>> obj.length 
5
```

Aunque los métodos pertenezcan al objeto String, podemos utilizarlos también directamente en datos de tipo primitivo string (se crea el objeto internamente)

```javascript
>>> "potato".length 
6
>>> "tomato"[0] 
"t"
>>> "potato"["potato".length - 1] 
"o"
```

Los objetos string disponen de los siguientes métodos:

- [`toUpperCase()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/String/toUpperCase)  devuelve el string convertido a mayúsculas

- [`toLowerCase()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/String/toLowerCase)  devuelve el string convertido a minusculas

- [`charAt()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/String/charAt)  devuelve el carácter encontrado en la posición indicada

- [`indexOf()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/String/indexOf) busca una cadena de texto en el string y devuelve la posición donde la encuentra
    - Si no encuentra nada devuelve -1 

- `lastIndexOf()` empieza la búsqueda desde el final de la cadena
    - Si no encuentra nada devuelve -1 
    
Por tanto la manera de correcta de chequear si existe una cadena de texto en otra es →  `if ( s.toLowerCase().indexOf('couch') !== -1 ) {...}`

- [`slice()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/String/slice) devuelve un trozo de la cadena de texto 

- [`split()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/String/split) transforma el string en un array utilizando un string como separador 

- [`concat()`](https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/String/concat) une strings

```javascript
>>> var s = new String("Couch potato");
>>> s.toUpperCase() 
"COUCH POTATO"
>>> s.toLowerCase() 
"couch potato"
>>> s.charAt(0); 
"C"
>>> s.indexOf('o') 
1
>>> s.lastIndexOf('o') 
11
>>> s.slice(1, 5) 
"ouch"
>>> s.split(" ") 
["Couch", "potato"]
>>> s.concat("es") 
"Couch potatoes"
```