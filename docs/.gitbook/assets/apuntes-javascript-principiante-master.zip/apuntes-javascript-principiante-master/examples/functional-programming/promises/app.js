import loadImagePromised
from './load-image-callbacked'